import React from 'react'

function test() {
  return (
    <div>test</div>
  )
}

export default test